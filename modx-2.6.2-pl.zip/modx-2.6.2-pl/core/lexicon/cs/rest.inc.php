<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Chyba!';
$_lang['rest.err_class_remove'] = 'Došlo k chybě při pokusu odebrat [[+class_key]]';
$_lang['rest.err_class_save'] = 'Došlo k chybě při pokusu uložit [[+class_key]]';
$_lang['rest.err_field_ns'] = '[[+field]] nebylo určeno!';
$_lang['rest.err_field_required'] = 'Tento údaj je povinný.';
$_lang['rest.err_fields_required'] = 'Následující pole jsou povinná: [[+fields]]';
$_lang['rest.err_obj_nf'] = '[[+class_key]] nenalezen!';
