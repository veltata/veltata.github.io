<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Löschen';
$_lang['error_log'] = 'Fehlerprotokoll';
$_lang['error_log_desc'] = 'Hier ist das Fehlerprotokoll für MODX Revolution:';
$_lang['error_log_download'] = 'Fehlerprotokoll herunterladen ([[+size]])';
$_lang['error_log_too_large'] = 'Das Fehlerprotokoll <em>[[+name]]</em> ist zu groß, um angezeigt zu werden. Sie können es mittels des untenstehenden Buttons herunterladen.';
$_lang['system_events'] = 'System-Ereignisse';
$_lang['priority'] = 'Priorität';