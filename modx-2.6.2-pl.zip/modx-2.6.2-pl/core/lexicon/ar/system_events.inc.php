<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'امسح';
$_lang['error_log'] = 'سجل الخطأ';
$_lang['error_log_desc'] = 'هنا هو سجل الخطأ لمودكس الثوري:';
$_lang['error_log_download'] = 'حمل سجل الخطأ ([[+size]])';
$_lang['error_log_too_large'] = 'سجل الخطأ عند <em>[[+name]]</em> كبير جدا ليتم عرضه. يمكنك تحميله عبر الزر أدناه.';
$_lang['system_events'] = 'أحداث النظام';
$_lang['priority'] = 'أولوية';